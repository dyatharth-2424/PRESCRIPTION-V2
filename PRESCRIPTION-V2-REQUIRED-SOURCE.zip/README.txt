PRESCRIPTION V2

This is a new Android project with a new application ID:
com.parasclinic.prescriptionv2

It can be installed alongside the old PRESCRIPTION V1.

Key features in this version:
- 2-inch header / letterhead space
- Patient ID and Patient Name are optional
- Permanent editable Medicine Library stored on the phone
- Add, edit, remove and search medicines
- Medicines remain alphabetically sorted
- Quantity column kept narrow
- Prescription can be saved locally
- Print / Save PDF uses the Android print dialog
- Initial medicine library is included and can be changed later

Build:
GitHub Actions workflow: .github/workflows/build-apk.yml
