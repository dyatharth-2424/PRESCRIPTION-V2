PRESCRIPTION V2 FINAL DESIGN

No random/preloaded medicine list.
No random/preloaded advice list.

The doctor creates the Medicine Library manually:
CODE -> MEDICINE NAME -> FORM -> DOSE -> DEFAULT QUANTITY -> DEFAULT INSTRUCTIONS

During prescribing, entering/selecting a code automatically fills the medicine row.

The doctor creates the Advice Library manually:
CODE -> ADVICE TEXT

During prescribing, entering/selecting an advice code automatically fills the advice.

Libraries are stored locally on the phone and remain editable.
Patient ID and Patient Name are optional.
Header/letterhead space is 2 inches.
Quantity column is narrow.
